#!/bin/bash
#!/usr/bin/bash
# Title			  : Palette Printer Bash
# Summary		  : This script prints color palette (see preview).
# Description : It works by using ASCI escape codes for background color.
# Created-at	: Monday, October 18, 2021
# Repository	: N/A
# Authors		  : Alex A. Davronov <al.neodim@gmail.com> (2021-)
# Description	: See README.MD
# Usage			  : $ palette.bash | less -SRq


###############################################################################################
#  Customize BASH PS1 prompt to show current GIT repository and branch.                       #
#  by Mike Stewart - https://gist.github.com/vratiu/9780109                                   #
#                                                                                             #
#  SETUP CONSTANTS                                                                            #
#  Bunch-o-predefined colors.  Makes reading code easier than escape sequences.               #
#  I don't remember where I found this.  o_O                                                  #
###############################################################################################

# Escape Sequence — available options: \x1b[ | \033[ | \e[
DefaultColorPrefix="\033["

# Reset Value
ResetColor="${DefaultColorPrefix}0m"


###############################################################################################
#                                  DEFAULT COLORS                                             #
#                 Available Contrasts: Regular, Bright, and High Intensity                    #
###############################################################################################

# Regular Colors
ColorIn_Black="${DefaultColorPrefix}0;30"          # Black
ColorIn_Red="${DefaultColorPrefix}0;31"            # Red
ColorIn_Green="${DefaultColorPrefix}0;32"          # Green
ColorIn_Yellow="${DefaultColorPrefix}0;33"         # Yellow
ColorIn_Blue="${DefaultColorPrefix}0;34"           # Blue
ColorIn_Purple="${DefaultColorPrefix}0;35"         # Purple
ColorIn_Cyan="${DefaultColorPrefix}0;36"           # Cyan
ColorIn_White="${DefaultColorPrefix}0;37"          # White

# Regular Colors — Bright
ColorIn_BrightRed="${DefaultColorPrefix}0;31;1"    # Bright Red
ColorIn_BrightGreen="${DefaultColorPrefix}0;32;1"  # Bright Green
ColorIn_BrightYellow="${DefaultColorPrefix}0;33;1" # Bright Yellow
ColorIn_BrightBlue="${DefaultColorPrefix}0;34;1"   # Bright Blue
ColorIn_BrightPurple="${DefaultColorPrefix}0;35;1" # Bright Purple
ColorIn_BrightCyan="${DefaultColorPrefix}0;36;1"   # Bright Cyan



# Regular Text Colors
TextColorIn_Black="${ColorIn_Black};0m"
TextColorIn_Red="${ColorIn_Red};0m"
TextColorIn_Green="${ColorIn_Green};0m"
TextColorIn_Yellow="${ColorIn_Yellow};1m"
TextColorIn_Blue="${ColorIn_Blue};0m"
TextColorIn_Purple="${ColorIn_Purple};0m"
TextColorIn_Cyan="${ColorIn_Cyan};0m"
TextColorIn_White="${ColorIn_White};1m"

# Regular Text Colors — Bright
TextColorIn_BrightRed="${ColorIn_BrightRed};1m"
TextColorIn_BrightGreen="${ColorIn_BrightGreen};1m"
TextColorIn_BrightYellow="${ColorIn_Yellow};1m"
TextColorIn_BrightBlue="${ColorIn_BrightBlue};1m"
TextColorIn_BrightPurple="${ColorIn_BrightPurple};1m"
TextColorIn_BrightCyan="${ColorIn_BrightCyan};1m"



# Bolded Text Color
TextBoldedColorIn_Black="${TextColorIn_Black};1m"
TextBoldedColorIn_Red="${TextColorIn_Red};1"
TextBoldedColorIn_Green="${TextColorIn_Green};1"
TextBoldedColorIn_Yellow="${TextColorIn_Yellow};1m"
TextBoldedColorIn_Blue="${TextColorIn_Blue};1m"
TextBoldedColorIn_Purple="${TextColorIn_Purple};1m"
TextBoldedColorIn_Cyan="${ColorIn_Cyan};1m"
TextBoldedColorIn_White="${ColorIn_White};1m"

# Bolded Text Color — Bright
TextBoldedColorIn_BrightRed="${TextColorIn_BrightRed};1m"
TextBoldedColorIn_BrightGreen="${TextColorIn_BrightGreen};1m"
TextBoldedColorIn_BrightYellow="${TextColorIn_BrightYellow};1m"
TextBoldedColorIn_BrightBlue="${TextColorIn_BrightBlue};1m"
TextBoldedColorIn_BrightPurple="${ColorIn_BrightPurple};1m"
TextBoldedColorIn_BrightCyan="${ColorIn_BrightCyan};1m"



# Italicized Text Color
TextItalicizedColorIn_Black="${TextColorIn_Black};3m"
TextItalicizedColorIn_Red="${TextColorIn_Red};3m"
TextItalicizedColorIn_Green="${TextColorIn_Green};3m"
TextItalicizedColorIn_Yellow="${TextColorIn_Yellow};3m"
TextItalicizedColorIn_Blue="${TextColorIn_Blue};3m"
TextItalicizedColorIn_Purple="${TextColorIn_Purple};3m"
TextItalicizedColorIn_Cyan="${ColorIn_Cyan};3m"
TextItalicizedColorIn_White="${ColorIn_White};3m"

# Italicized Text Color — Bright
TextItalicizedColorIn_BrightRed="${TextColorIn_BrightRed};3m"
TextItalicizedColorIn_BrightGreen="${TextColorIn_BrightGreen};3m"
TextItalicizedColorIn_BrightYellow="${TextColorIn_BrightYellow};3m"
TextItalicizedColorIn_BrightBlue="${TextColorIn_BrightBlue};3m"
TextItalicizedColorIn_BrightPurple="${ColorIn_BrightPurple};3m"
TextItalicizedColorIn_BrightCyan="${ColorIn_BrightCyan};3m"



# Underlined Text Color
TextUnderlinedColorIn_Black="${TextColorIn_Black};4m"
TextUnderlinedColorIn_Red="${TextColorIn_Red};4m"
TextUnderlinedColorIn_Green="${TextColorIn_Green};4m"
TextUnderlinedColorIn_Yellow="${TextColorIn_Yellow};4m"
TextUnderlinedColorIn_Blue="${TextColorIn_Blue};4m"
TextUnderlinedColorIn_Purple="${TextColorIn_Purple};4m"
TextUnderlinedColorIn_Cyan="${ColorIn_Cyan};4m"
TextUnderlinedColorIn_White="${ColorIn_White};4m"

# Underlined Text Color — Bright
TextUnderlinedColorIn_BrightRed="${TextColorIn_BrightRed};4m"
TextUnderlinedColorIn_BrightGreen="${TextColorIn_BrightGreen};4m"
TextUnderlinedColorIn_BrightYellow="${TextColorIn_BrightYellow};4m"
TextUnderlinedColorIn_BrightBlue="${TextColorIn_BrightBlue};4m"
TextUnderlinedColorIn_BrightPurple="${ColorIn_BrightPurple};4m"
TextUnderlinedColorIn_BrightCyan="${ColorIn_BrightCyan};4m"



# Strikethrough Text Color
TextStrikethroughIn_Black="${TextColorIn_Black};9m"
TextStrikethroughIn_Red="${TextColorIn_Red};9m"
TextStrikethroughIn_Green="${TextColorIn_Green};9m"
TextStrikethroughIn_Yellow="${TextColorIn_Yellow};9m"
TextStrikethroughIn_Blue="${TextColorIn_Blue};9m"
TextStrikethroughIn_Purple="${TextColorIn_Purple};9m"
TextStrikethroughIn_Cyan="${ColorIn_Cyan};9m"
TextStrikethroughIn_White="${ColorIn_White};9m"

# Strikethrough Text Color — Bright
TextStrikethroughIn_BrightRed="${TextColorIn_BrightRed};9m"
TextStrikethroughIn_BrightGreen="${TextColorIn_BrightGreen};9m"
TextStrikethroughIn_BrightYellow="${TextColorIn_BrightYellow};9m"
TextStrikethroughIn_BrightBlue="${TextColorIn_BrightBlue};9m"
TextStrikethroughIn_BrightPurple="${ColorIn_BrightPurple};9m"
TextStrikethroughIn_BrightCyan="${ColorIn_BrightCyan};9m"



# High Intensity
TextHighIntensityIn_Black="${DefaultColorPrefix}0;90m"       # Black
TextHighIntensityIn_Red="${DefaultColorPrefix}0;91m"         # Red
TextHighIntensityIn_Green="${DefaultColorPrefix}0;92m"       # Green
TextHighIntensityIn_Yellow="${DefaultColorPrefix}0;93m"      # Yellow
TextHighIntensityIn_Blue="${DefaultColorPrefix}0;94m"        # Blue
TextHighIntensityIn_Purple="${DefaultColorPrefix}0;95m"      # Purple
TextHighIntensityIn_Cyan="${DefaultColorPrefix}0;96m"        # Cyan
TextHighIntensityIn_White="${DefaultColorPrefix}0;97m"       # White



# Bold High Intensity
TextHighIntensityBoldedIn_Black="${DefaultColorPrefix}1;90m"      # Black
TextHighIntensityBoldedIn_Red="${DefaultColorPrefix}1;91m"        # Red
TextHighIntensityBoldedIn_Green="${DefaultColorPrefix}1;92m"      # Green
TextHighIntensityBoldedIn_Yellow="${DefaultColorPrefix}1;93m"     # Yellow
TextHighIntensityBoldedIn_Blue="${DefaultColorPrefix}1;94m"       # Blue
TextHighIntensityBoldedIn_Purple="${DefaultColorPrefix}1;95m"     # Purple
TextHighIntensityBoldedIn_Cyan="${DefaultColorPrefix}1;96m"       # Cyan
TextHighIntensityBoldedIn_White="${DefaultColorPrefix}1;97m"      # White




###############################################################################################
#                                 BACKGROUND COLORS                                           #
#                Available Contrasts: Regular, and High Intensity                             #
###############################################################################################

# Background In {color}
BackgroundColorIn_Black="${DefaultColorPrefix}40m"       # Black
BackgroundColorIn_Red="${DefaultColorPrefix}41m"         # Red
BackgroundColorIn_Green="${DefaultColorPrefix}42m"       # Green
BackgroundColorIn_Yellow="${DefaultColorPrefix}43m"      # Yellow
BackgroundColorIn_Blue="${DefaultColorPrefix}44m"        # Blue
BackgroundColorIn_Purple="${DefaultColorPrefix}45m"      # Purple
BackgroundColorIn_Cyan="${DefaultColorPrefix}46m"        # Cyan
BackgroundColorIn_White="${DefaultColorPrefix}47m"       # White

# High Intensity backgrounds
BackgroundColorHighIntensityIn_Black="${DefaultColorPrefix}0;100m"   # Black
BackgroundColorHighIntensityIn_Red="${DefaultColorPrefix}0;101m"     # Red
BackgroundColorHighIntensityIn_Green="${DefaultColorPrefix}0;102m"   # Green
BackgroundColorHighIntensityIn_Yellow="${DefaultColorPrefix}0;103m"  # Yellow
BackgroundColorHighIntensityIn_Blue="${DefaultColorPrefix}0;104m"    # Blue
BackgroundColorHighIntensityIn_Purple="${DefaultColorPrefix}10;95m"  # Purple
BackgroundColorHighIntensityIn_Cyan="${DefaultColorPrefix}0;106m"    # Cyan
BackgroundColorHighIntensityIn_White="${DefaultColorPrefix}0;107m"   # White




###############################################################################################
#   PS1 PROMPT VARIABLES                                                                      #
#                                                                                             #
#   Time                                                                                      #
#   Path                                                                                      #
#   New Line                                                                                  #
#   Jobs                                                                                      #
#   Git                                                                                       #
###############################################################################################

# Various variables you might want for your PS1 prompt instead
TimeIn12h="\T"
TimeIn12a="\@"
PathInShort="\w"
PathInFull="\W"
NewLine="\n"
Jobs="\j"


# This PS1 snippet was adopted from code for MAC/BSD with tweaks to make
# it work on UBUNTU 11.04 & 11.10 plus made it better

export PS1=$TextHighIntensityIn_Black$TimeIn12h$ResetColor'$(git branch &>/dev/null;\
if [ $? -eq 0 ]; then \
  echo "$(echo `git status` | grep "nothing to commit" > /dev/null 2>&1; \
  if [ "$?" -eq "0" ]; then \
    # @4 - Clean repository - nothing to commit
    echo "'$TextColorIn_Green'"$(__git_ps1 " (%s)"); \
  else \
    # @5 - Changes to working tree
    echo "'$TextHighIntensityIn_Red'"$(__git_ps1 " {%s}"); \
  fi) '$TextBoldedColorIn_Yellow$PathInShort$ResetColor'\$ "; \
else \
  # @2 - Prompt when not in GIT repo
  echo " '$TextColorIn_Yellow$PathInShort$ResetColor'\$ "; \
fi)'

# enable this flag ONLY if you are working with an internal repository that doesn't have a valid certificate
# export GIT_SSL_NO_VERIFY=true

git config --global alias.lg "log --color --graph --pretty=format:'%Cred%h%Creset -%C(yellow)%d%Creset %s %Cgreen(%cr)%C(bold blue)<%an>%Creset' --abbrev-commit"



##########
echo -e "I \033[0;33m love ${ResetColor} Linux"
echo -e "I \033[1;35m love ${ResetColor} Linux"
echo -e "I \033[0;37m love ${ResetColor} Linux"
echo -e "I \033[1;19h love ${ResetColor} Linux"
##########


T='gYw'   # The test text

echo -e "\n                 40m     41m     42m     43m\
     44m     45m     46m     47m";

for FGs in '    m' '   1m' '  30m' '1;30m' '  31m' '1;31m' '  32m' \
           '1;32m' '  33m' '1;33m' '  34m' '1;34m' '  35m' '1;35m' \
           '  36m' '1;36m' '  37m' '1;37m';
  do FG=${FGs// /}
  echo -en " $FGs \033[$FG  $T  "
  for BG in 40m 41m 42m 43m 44m 45m 46m 47m;
    do echo -en "$EINS \033[$FG\033[$BG  $T  \033[0m";
  done
  echo;
done
echo