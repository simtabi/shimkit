#!/bin/bash
echo "Please enter your Laravel project path."
read project;

cd "$project/.."
sudo find "$project" -type f -exec chmod 664 {} \;
sudo find "$project" -type d -exec chmod 775 {} \;

cd "$project"
sudo chgrp -R www-data storage bootstrap/cache
sudo chmod -R ug+rwx storage bootstrap/cache

cd "$project"
sudo rm -rf storage/logs/*.log
sudo chmod g+s storage/logs/
sudo setfacl -d -m g::rwx storage/logs/

# Reset Symlink
sudo php artisan storage:link --force
