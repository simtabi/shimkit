#!/bin/bash
sudo apt update
sudo apt install nginx nginx-extras -y
echo "Check Your IP with: curl -4 icanhazip.com"


apache_packages=(
"apache2"

)

nginx_packages=(
  "nginx"
"nginx-extras"
)