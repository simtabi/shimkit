#!/bin/bash

php_version="8.2"
php_version_hyphenated="${php_version}"

## PHP Modules
php_modules=(

)

## Apache Modules
apache_modules=(
"libapache2-mod-md"
"libapache2-mod-php"
"libapache2-mod-security2"
"libapache2-mod-php${php_version}"
"libphp${php_version_hyphenated}embed"
"libsmbclient-dev"
)

installPHPPackages() {
  for pkg in "${php_modules[@]}"
  do
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "$pkg"
  done
}


php_versions=(
"php"
"php${php_version}"

)

php_extensions=(
"php${php_version_hyphenated}apcu"
"php${php_version_hyphenated}bcmath"
"php${php_version_hyphenated}bz2"
"php${php_version_hyphenated}cgi"
"php${php_version_hyphenated}cli"
"php${php_version_hyphenated}common"
"php${php_version_hyphenated}curl"
"php${php_version_hyphenated}dev"
"php${php_version_hyphenated}dom"
"php${php_version_hyphenated}gd"
"php${php_version_hyphenated}gettext"
"php${php_version_hyphenated}gmp"
"php${php_version_hyphenated}igbinary"
"php${php_version_hyphenated}imagick"
"php${php_version_hyphenated}imap"
"php${php_version_hyphenated}intl"
"php${php_version_hyphenated}json"
"php${php_version_hyphenated}ldap"
"php${php_version_hyphenated}mbstring"
"php${php_version_hyphenated}mcrypt"
"php${php_version_hyphenated}mongodb"
"php${php_version_hyphenated}mysql"
"php${php_version_hyphenated}opcache"
"php${php_version_hyphenated}pea"
"php${php_version_hyphenated}pear"
"php${php_version_hyphenated}phpdbg"
"php${php_version_hyphenated}phpseclib"
"php${php_version_hyphenated}readline"
"php${php_version_hyphenated}redis"
"php${php_version_hyphenated}soap"
"php${php_version_hyphenated}sqlite3"
"php${php_version_hyphenated}ssh2"
"php${php_version_hyphenated}tcpdf"
"php${php_version_hyphenated}tidy"
"php${php_version_hyphenated}xml"
"php${php_version_hyphenated}xmlrpc"
"php${php_version_hyphenated}zip"
)

installPHPPackages() {
  for pkg in "${php_modules[@]}"
  do
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "$pkg"
  done

  echo "=============================== DONE INSTALLING PHP MODULES ===================================="
}

installPHP() {
  sudo apt install software-properties-common -y
  sudo add-apt-repository ppa:ondrej/php
  sudo apt-get update
  echo "=============================== DONE INSTALLING PHP [ppa:ondrej/php] ===================================="
}

installApache() {
  echo "Add the ondrej PPA for Apache."

  sudo add-apt-repository ppa:ondrej/apache2
  sudo apt-get update
  echo "=============================== DONE INSTALLING APACHE [ppa:ondrej/apache2] ===================================="
}

installNGiNX_PHP_FPM() {
  echo "Add the ondrej PPA for NGINX"
  sudo add-apt-repository ppa:ondrej/nginx

  echo "Install and Configure PHP-FPM"
  sudo apt install "php${php_version_hyphenated}fpm"
  sudo apt install libapache2-mod-fcgid

  sudo apt-get update
  echo "=============================== DONE INSTALLING APACHE [NGiNX, PHP FPM & libapache2-mod-fcgid] ===================================="
}

enableApacheFPMModules() {
  echo "Enable the Apache modules required by FPM."

  sudo a2enmod actions fcgid alias proxy_fcgi
  echo "=============================== DONE ENABLING APACHE FPM MODULES ===================================="
}









sudo apt install software-properties-common -y
sudo apt-get update
sudo apt install php8.1-fpm
sudo apt install /extensions/ -y
echo "===============================DONE INSTALLING PHP8.1===================================="



