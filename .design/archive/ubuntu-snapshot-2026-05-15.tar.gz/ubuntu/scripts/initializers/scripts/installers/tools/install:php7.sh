#!/bin/bash
sudo apt install software-properties-common -y
sudo add-apt-repository ppa:ondrej/php
sudo apt-get update
sudo apt install php8.0 php8.0-common -y
sudo apt install -packages/extentions- -y

echo "To verify just run following command"
echo "php -m"
echo "php --ini