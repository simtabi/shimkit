


echo " ╔════════════════════════════════════════════════════════════════════╗ "
echo " ║                      JREAM - Ubuntu Installer                      ║ "
echo " ║                      Target: 22.04 Jammy                           ║ "
echo " ╠════════════════════════════════════════════════════════════════════╣ "
echo " ║ Installation runs after command is entered.                        ║ "
echo " ║ View OUTPUT.LOG when complete.                                     ║ "
echo " ║                                                                    ║ "
echo " ║ (q) to Quit                                      (Or press CTRL+C) ║ "
echo " ╚════════════════════════════════════════════════════════════════════╝ "
echo ""
sleep 1

