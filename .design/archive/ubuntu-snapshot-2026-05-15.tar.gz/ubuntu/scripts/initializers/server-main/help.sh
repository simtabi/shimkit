echo "Commands Available are
    help                  Display this help menu
    add:cron              Add a new cron job
    create:db             Create new MySQL database table
    install:certbot       Install Certbot for Nginx
    install:composer      Install and setup Composer
    install:mysql         Install and setup Mysql Server
    install:node          Install and setup NodeJS
    install:nginx         Install and setup Nginx
    install:php           Install and setup PHP 8
    install:php7          Install and setup PHP 7.4
    install:postgres      Install and setup Postgres SQL
    nginx:host            Setup new nginx host
    laravel:setup         Setup laravel project
    laravel:file-perms    Setup laravel project file permission
    expressjs:setup       Setup ExpressJs, and NodeJS projects
    configs:supervisor    Create new Supervisor Conf File
"
